# Data

# Number of individuals

NInd <- 138

# logMass

logMass <- as.matrix(read.csv("logMass.csv"))

colnames(logMass) <- NULL

# PDSI

PDSI <- read.csv("PDSI.csv")$x

# SVL0

SVL0 <- read.csv("SVL0.csv")$SVL

# SVL

SVL <- as.matrix(read.csv("SVL.csv"))

colnames(SVL) <- NULL

# Summer days

summerDays <- read.csv("summerDays.csv")$x

# Winter days

winterDays <- read.csv("winterDays.csv")$x

# Model

model{
  
  for (i in 1:NInd){     # Looping over all capture records in order (i.e., no need to format as a capture history)

    # Sex of unknown individuals
    Sex[i] ~ dbern(p.male)
    L.inf[i] <- L.inf.female + B.male*Sex[i]   # asymptotic size depends on sex

    # Calculate mass as a function of drought, SVL, sex at first capture
    logMass[i,f[i]] ~ dnorm(logMassMu[i,f[i]], tau.Mass)
    logMassMu[i,f[i]] <- logA[i,f[i]] + b*log(SVL[i,f[i]]) 
    logA[i,f[i]] <- B0 + B1*Sex[i] B2*PDSI[f[i]]
    
    # Size at first capture - f vector stores the occasion of first capture for each individual
    SVL[i,f[i]] ~ dnorm(SVL0[i,f[i]], tau.SVL)  # SVL[i,f[i]] is measured size at first capture
    SVL0[i,f[i]] ~ dunif(190,600)               # SVL0[i,f[i]] is the true size at first capture


    for (j in (f[i]+1):l[i]){   # for j in second observation to last observation - l stores occasion of last capture
     
        logMass[i,j] ~ dnorm(logMassMu[i,j], tau.Mass)
        logMassMu[i,j] <- logA[i,j] + b*log(SVL[i,j]) 
        logA[i,j] <- B0 + B1*Sex[i] + B2*PDSI[j] 
        
        SVL[i,j] ~ dnorm(SVL0[i,j], tau.SVL) 
        SVL0[i,j] <- SVL0[i,j-1] +
                     (L.inf[i] - SVL0[i,j-1]) *
                     (1 - exp(-(kS[i,j]*summerDays[j]/365) - (kW*winterDays[j]/365)))
        
        kS[i,j] <- a0 + a1*Sex[i] + a2*PDSI[j]

    }
  }
 
  # Prior Specification
  
  # Probability of being male
  p.male ~ dunif(0, 1)   # interpolating for individuals of unknown sex
 
  # Asymptotic size parameter
  L.inf.female ~ dnorm(450,.0001)T(0,)  # Intercept for asymptotic size is for females
  B.male ~ dnorm(0,.0001)     # Coefficient for difference in asymptotic size for males
  L.inf.male <- L.inf.female + B.male      # Derived parameter that calculates estimated asym. size for males

  # growth parameters (length)
  a0 ~ dnorm(0.2, 0.01)T(0,)  # Female summer growth intercept
  a1 ~ dnorm(0, 0.01)  # Effect of maleness on growth
  a2 ~ dnorm(0, 0.01)  # Effect of PDSI on growth
  kW ~ dnorm(0.1, 0.01)T(0,)  # winter growth
  tau.SVL ~ dgamma(1,0.001) #dgamma(shape = 1, rate = 10000)  # prior on precision
  sigma.SVL <- sqrt(1/tau.SVL)  # converting precision to sd

  # log(mass)
  B0 ~  dnorm(-10, 0.01)
  B1 ~  dnorm(0, 0.01)
  B2 ~  dnorm(0, 0.01)
  b ~  dnorm(3, 0.01)T(0.0001,)
  tau.Mass ~ dgamma(1, 0.001)
  sigma.Mass <- sqrt(1/tau.Mass)
  
}
